module crystal{
    requires calculator;
    exports crystal_inner;
}