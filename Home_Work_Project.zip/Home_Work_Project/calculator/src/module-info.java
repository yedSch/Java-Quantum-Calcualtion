module calculator{
    exports calculator_inner;
}