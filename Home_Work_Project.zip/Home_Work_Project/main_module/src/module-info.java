module main_module {
    requires calculator;
    requires crystal;
}